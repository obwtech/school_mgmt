
# St. Patrick's Girls High School - Mbiuni: School Management System

## Features Included
- Student Management
- Teacher Management
- Exams and Grades
- Fees Tracking
- Class Timetable
- School Info (Motto, Logo, Colors)
- Admin/Teacher/Student Login System
- Sample Data for Demo
- SQLite Backend (default, easy to switch)
- Django 4+ Ready

## Getting Started
1. Unzip the project.
2. Navigate into the project folder.
3. Create virtual environment and activate:
   ```
   python -m venv env
   source env/bin/activate  # Linux/macOS
   env\Scripts\activate   # Windows
   ```
4. Install requirements:
   ```
   pip install -r requirements.txt
   ```
5. Run migrations:
   ```
   python manage.py migrate
   ```
6. Create superuser:
   ```
   python manage.py createsuperuser
   ```
7. Run the server:
   ```
   python manage.py runserver
   ```

## Login Roles
- Admin: Full access
- Teacher: Subject/class assigned access
- Student: Report card/timetable view
- Accounts: Fees only

---
System built for: **St. Patrick's Girls High School - Mbiuni**  
Motto: *Decision Decides Destiny*
    